# RN Rice Mill Website

A responsive static website for RN Rice Mill built with HTML, CSS and JavaScript.

## Files
- `index.html` — page structure and content
- `style.css` — layout, colours, responsive styling
- `script.js` — mobile menu and automatic copyright year

## Run locally
Open `index.html` in a web browser.

## Deploy on GitHub Pages
1. Create a GitHub repository and upload all three website files to the repository root.
2. Open the repository's **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch `main` and folder `/ (root)`, then save.
5. Wait for the Pages deployment to finish; the website URL will appear in that Pages section.

Before publishing, replace the placeholder email in `index.html` with the real business email.
